﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecursiveTypes
{
   class Program
   {
      static void Main( string[] args )
      {
         LinkedList ll = new LinkedList();
         ll.Add( "Hello" );
         ll.Add( "World" );

         // TODO: Use foreach to iterate through ll
      }
   }
}
